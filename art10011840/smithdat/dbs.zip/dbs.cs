// Database helper class to get a decent speed out of APL Table.Select stuff
// Special-case DateTime and TimeSpan as OLEDate and double and substitute all DBNull entries
// (c) Adrian Smith (adrian@apl385.com) March 2007
// Compile with   csc /t:library dbs.cs

using System.Data;
using System;

namespace Causeway {   

public class Db { // Short names R us
 
 public readonly DataTable Table;
 private DataRow[] Selection;
 private string expr = "";
 private string sort = "";
 private string whoami = "";
 private object[] nullFillers;
 private bool[] isDate;
 private bool[] isSpan;
 private Type[] APLTypes;
 
 public Db(DataTable table)   // Wrap an entire table (common case)
 { Table = table; whoami = "Data from " + table.TableName; initGlobals(); }
 
 public Db(DataTable table, string selexpr)   // Wrap a table noting a selection
 { Table = table; expr = selexpr;
   whoami = "Selection from " + Table.TableName + " where " + selexpr;
   initGlobals();
 }

 public Db(DataTable table, string selexpr, string sortexpr)   // Wrap a table with a sorted selection
 { Table = table; expr = selexpr; sort = sortexpr;
   if(0<expr.Length)  // They may just want to sort everything!
     whoami = "Selection from " + Table.TableName + " where " + expr + " sorted by " + sort;
   else
     whoami = "Selection from " + Table.TableName + " sorted by " + sort;
   initGlobals();
 }

 private void initGlobals()
 {
   Selection = Table.Select(expr,sort);
   nullFillers = new object[Cols]; APLTypes = new Type[Cols];
   isDate = new bool[Cols]; isSpan = new bool[Cols];
  // Make a sensible set of null fillers for APL to use where we hit unset data! 
   for(int col=0;col<nullFillers.Length; col++) {
     Type coltype = Table.Columns[col].DataType;
     APLTypes[col] = coltype;
     if(typeof(String) == coltype)
			 nullFillers[col] = "(null)"; 
		 else if(typeof(DateTime) == coltype)
			 { nullFillers[col] = (double)(-1); isDate[col] = true; APLTypes[col] = typeof(Double); }   
		 else if(typeof(TimeSpan) == coltype)
			 { nullFillers[col] = (double)0; isSpan[col] = true; APLTypes[col] = typeof(Double); }    
		 else  // All numbers get the same int16 flag but correctly cast
       nullFillers[col] = Convert.ChangeType(-32768,coltype);  
   }    
 }
 
 public string Reselect()  // Useful if data was added behind our back!
 { Selection = Table.Select(expr,sort);  return ToString(); }
 
 public override string ToString()  // Display format for APL to echo
 { return whoami + " (" + Selection.Length + " rows selected)"; } 
	
// ================== Read data by Column or Row vector ======================

 private object GetItem(int row, int col)  // Return one cell, checking for type and null
 { object cellvalue = Selection[row][col];
   if(System.DBNull.Value == cellvalue)    // APL really hates these
     cellvalue = nullFillers[col];         // Plug in current filler instead 
   else if(isDate[col])
     cellvalue = ((DateTime)cellvalue).ToOADate();
   else if(isSpan[col])
     cellvalue = ((TimeSpan)cellvalue).TotalSeconds;
   return cellvalue;  
 }
 
 public Array GetCol(int cinx)   // Grab whole Column (ensure APL gets the right datatype) 
 { int col = cinx-1;             // Fix for 1-origin
   Type coltype = APLTypes[col];
   Array coldata = Array.CreateInstance(coltype,Selection.Length);
   for(int row=0;row<coldata.Length;row++) 
     coldata.SetValue(GetItem(row,col),row);
   return coldata;  
 }
 
 public object[][] GetRows(int[] rinx)  // Grab several rows as vector of field vectors
 { object[][] rowdata = new object[rinx.Length][];
   for(int ct = 0;ct<rinx.Length;ct++)
     rowdata[ct] = GetRow(rinx[ct]);
   return rowdata;
 }
 
 public object[] GetRow(int rinx) // Grab one row (result not enclosed) as field vector
 { object[] rowdata = new object[Cols];
   int row = rinx-1;              // Fix origin
   for(int col=0; col<Cols; col++)
     rowdata[col] = GetItem(row,col);
   return rowdata;
 }
 
 public object[,] GetMatrix()  // Grab the whole damn Selection as a Matrix
 { object[,] selmat = new object[Rows,Cols];
   for(int row = 0;row<Selection.Length;row++) 
     for(int col=0;col<Cols;col++)
       selmat[row,col] = GetItem(row,col);
   return selmat;
 }

// ============================= Update data by Column or Row ========================

 private void PutItem(int row, int col, object newValue)  // Fix one cell
	{ Selection[row][col] = Dyalog2Data(col,newValue); }
 
 private object Dyalog2Data(int col, object dataitem)   // APL types --> Database types 
 { Type coltype = APLTypes[col];
   
	  object newValue = Convert.ChangeType(dataitem,coltype);
	  
		 if(NullFillers[col].Equals(newValue))
		   newValue = System.DBNull.Value;
		 else if(isDate[col]) 
       newValue = DateTime.FromOADate((double)newValue);
     else if (isSpan[col]) 
       newValue = TimeSpan.FromSeconds((double)newValue);  
     
		 return newValue;
 }
 
 public void PutCol(int cinx, object[] newValues)  // Update data colwise (always an entire column)
 { int col = cinx-1; 
   for(int row = 0;row<Selection.Length;row++)
     PutItem(row,col,newValues[row]);
 }
 
// public void PutCol(int cinx, object newValue)  // Update data colwise (scalar extension)
//	{  int col = cinx-1; 
//	   for(int row = 0;row<Selection.Length;row++)
//	     PutItem(row,col,newValue);
// }
 
 public void PutRow(int rinx, object[] newValues) // Fix one row as field vector
	 { int row = rinx-1;                       // Origin adjustment
	   bool[] canfix = Writeable;              // Be careful with expressions in columns!
	   for(int col=0; col<canfix.Length; col++)
	     if(canfix[col]) 
	       PutItem(row,col,newValues[col]);
	 }
 
 public void PutRows(int[] rinx, object[][] newValues) // Fix several rows at a time
	 { for(int ct = 0; ct<rinx.Length; ct++)
	     PutRow(rinx[ct], newValues[ct]);
	 }
	 
 public void Delete(int rowinx)  // Remove a row (1-origin) and redo selection
 { Selection[rowinx-1].Delete();
   Selection = Table.Select(expr,sort);
 }
 
 public void Delete(int[] rowinx)  // Remove several rows (1-origin) and redo selection
	{ for(int ct = 0; ct<rowinx.Length; ct++)
	    Selection[rowinx[ct]-1].Delete();
	  Selection = Table.Select(expr,sort);
 }
 
 public void PutFillers(object[] fillers)  // APL always hands us the full set
 { for(int col=0; col<NullFillers.Length; col++)
     if(typeof(String) == Table.Columns[col].DataType)
			nullFillers[col] = fillers[col].ToString();  
	   else if(typeof(DateTime) == Table.Columns[col].DataType)  // Really OADates
	 	  nullFillers[col] = Convert.ChangeType(fillers[col],typeof(System.Double));   
		 else if(typeof(TimeSpan) == Table.Columns[col].DataType)  // Really decimal secs
			nullFillers[col] = Convert.ChangeType(fillers[col],typeof(System.Double));     
		 else                                                      // As per colspec
      NullFillers[col] = Convert.ChangeType(fillers[col],Table.Columns[col].DataType);
 }
 
// ============== Assorted utilities for things APL finds hard =======================
 
// Much more comfortable just to pass column numbers when creating tables! 
 public static void SetPrimaryKey(DataTable table, int col) { SetPrimaryKey(table, new int[] {col}); } // Set a single key
 public static void SetPrimaryKey(DataTable table, int[] cols) // Set these 1-origin col nums as the primary key
 { DataColumn[] keys = new DataColumn[cols.Length];
   for(int ct=0; ct<cols.Length; ct++)
     keys[ct] = table.Columns[cols[ct]-1];
   table.PrimaryKey = keys;  
 }
 
 public void LoadArray(object[][] colwise)  // Bulk insert of several (big) columns
 { 
   int nrows = colwise[0].Length;  // Ragged data not expected!
   int ncols = colwise.Length;
   object[] dataarray = new object[ncols];
   Table.BeginLoadData();              // Turn off events
   for(int row=0; row<nrows; row++) {  // Transpose from cols to rows
     for(int col=0; col<ncols; col++)
       dataarray[col] = Dyalog2Data(col,colwise[col][row]);
     Table.LoadDataRow(dataarray,false);
   }
   Table.EndLoadData(); Table.AcceptChanges();  // Nail it all down
   Selection = Table.Select(expr,sort);  // Get everything back inline 
 }
 
// =================== Assorted thin covers as properties ========================	

  public int Rows { get { return Selection.Length; } }     // Rows
	public int Cols { get { return Table.Columns.Count; } }  // Cols
	
	public string[] ColumnNames { 
	  get { string[] names = new string[Cols];
	    for (int col = 0; col<names.Length; col++) 
	      names[col] = Table.Columns[col].ColumnName;
	    return names;  
	  }
	}
	
	public bool[] Writeable {
		 get { bool[] canwrite = new bool[Cols];
		   for (int col = 0; col<canwrite.Length; col++) 
		     canwrite[col] = !Table.Columns[col].ReadOnly;
		   return canwrite;  
		 }
	}
	
	public object[] NullFillers {	get { return nullFillers; } }
	
}
}
	