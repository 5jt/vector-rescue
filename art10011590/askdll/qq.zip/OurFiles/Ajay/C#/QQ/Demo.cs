using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace QuoteQuad
{
    public delegate void EventDel();
    [InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIDispatch)]
    public interface UserEvents
    {
        [DispId(5)]
        void MyEvent();
    }
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface _Demo
    {
        [DispId(1)]
        int MyMethod(int numarg);
        [DispId(2)]
        string MMethod();
        [DispId(3)]
        int MyProperty { get; set;}
        [DispId(4)]
        void eventm();
    }
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("QuoteQuad.Demo")]
    [ComSourceInterfaces(typeof(UserEvents))]
    public class Demo : _Demo
    {
        public event EventDel MyEvent;
        public Demo()
        {
        }
        private int myVar;
        public int MyProperty
        {
            get { return myVar; }
            set
            {
                MyEvent();
                myVar = value;
            }
        }
        public int MyMethod(int numarg)
        {
            return numarg + 10;
        }
        public string MMethod()
        {
            return "Ajay Askoolum";
        }
        public void eventm()
        {
            MyEvent();
        }

    }
}
